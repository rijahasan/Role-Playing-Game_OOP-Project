#include <SDL.h>
#include "drawing.hpp"
#include "Classmember.hpp"
#pragma once
using namespace std;


class RahimBhai : public Classmember{       //only has interactions
    public:
    void draw();
    RahimBhai();
};
