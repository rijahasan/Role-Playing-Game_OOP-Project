#include<SDL.h>
#include "RahimBhai.hpp"

void RahimBhai :: draw(){ //doesnt do anyth
}

RahimBhai :: RahimBhai(){
}
